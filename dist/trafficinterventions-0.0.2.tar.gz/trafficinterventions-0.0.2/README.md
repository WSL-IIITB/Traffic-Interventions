# Traffic-Interventions

## Installation
- `python -m pip install --upgrade pip`
- `pip install trafficinterventions xml`
