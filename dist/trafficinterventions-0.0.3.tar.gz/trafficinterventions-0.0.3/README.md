# Traffic-Interventions

## Installation
- `python -m pip install --upgrade pip`
- `pip install trafficinterventions xml`

## Documentation
All relevant files can be found [here](https://github.com/WSL-IIITB/Traffic-Interventions/tree/main/docs)
